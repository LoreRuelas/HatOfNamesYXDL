#include <stdio.h>
#include <stdlib.h>
#include <time.h>       /* time */
#include <string.h>

#define MAX_LINE_SIZE 100

int GeneradorRandom(char * nombreArchivo);
void GenerarDuplicado(char *nombreArchivo);
FILE* AbrirArchivo(char *nombreArchivo, char *toDo);
void BorrarArchivo(char *nombreArchivo);

int main(int argc, char *argv[]) {
    if ( argc < 2 ) {
        printf("Favor de especificar el archivo fuente\n");
        return 0;
    }
    GenerarDuplicado(argv[1]);
    // Codigo principal
    char opc;
    do {
        fflush(stdin);
        int completo = GeneradorRandom("Copia");
        if ( completo == 0 ) {
            printf("Se termino la lista\n");
            break;
        }
        scanf("%c",&opc);
    }while(opc == '\n');

    BorrarArchivo("Copia");
    return 0;
}

void BorrarArchivo(char *nombreArchivo){
    remove(nombreArchivo);
}

FILE* AbrirArchivo(char *nombreArchivo, char *toDo){
    // Abrir Archivo Original
    FILE *mi_descriptor = NULL;
    mi_descriptor = fopen(nombreArchivo, toDo);
    int line_count= 0;

    // Checar que no sea NULL
    if (mi_descriptor == NULL){
        printf("No se pudo abrir el archivo\n");
        //return 0xF0;
    }
    return mi_descriptor;
}
void GenerarDuplicado(char *nombreArchivo){
    FILE *Original = AbrirArchivo(nombreArchivo, "r");

    FILE *Duplicado = AbrirArchivo("Copia", "w");
    char *line = malloc(sizeof(char)*MAX_LINE_SIZE);

    while (1)
    {
        line = fgets(line, MAX_LINE_SIZE, Original);
        if (line == NULL){
            break;
        }
        fputs(line, Duplicado);
    }

    printf("\nContents copied to %s", line);

    fclose(Original);
    fclose(Duplicado);

}

int GeneradorRandom(char * nombreArchivo){
    // Abrir Archivo
    FILE *mi_descriptor = NULL;
    mi_descriptor = fopen(nombreArchivo, "r");
    int line_count= 0;

    // Checar que no sea NULL
    if (mi_descriptor == NULL){
        printf("No se pudo abrir el archivo\n");
        return 0;
    }

    // Reservar espacio
    char *line = malloc(sizeof(char)*MAX_LINE_SIZE);

    // cuenta lineas
    while ((fgets(line, MAX_LINE_SIZE, mi_descriptor)) != NULL){
        line_count ++;
        // printf("%s",line);
    }
    if ( line_count == 0 ) {
        return 0;
    }

    // Generar número random
    int randomNumber;
    // initialize random seed: */
    srand (time(NULL));

    // genera un número random entre el 1 y el line_count: */
    randomNumber = rand() % line_count + 1;
    // printf("\nRandom num: %d\n", randomNumber);


    rewind(mi_descriptor);
    for (int i = 0; i < randomNumber; i++ ){
        fgets(line, MAX_LINE_SIZE, mi_descriptor);
    }
    printf("Estudiante a participar: %s", line);

    FILE *temporal = AbrirArchivo("Temporal", "w");
    rewind(mi_descriptor);
    char *linetemp = malloc(sizeof(char)*MAX_LINE_SIZE);
    while (1)
    {
        linetemp = fgets(linetemp, MAX_LINE_SIZE, mi_descriptor);
        if (linetemp == NULL){
            break;
        }
        if ( strcmp(linetemp, line ) == 0 ) {
            continue;
        }
        fputs(linetemp, temporal);
    }
    fclose(mi_descriptor);
    fclose(temporal);
    remove(nombreArchivo);
    //rename the file replica.c to original name
    rename("Temporal", nombreArchivo);
    return 1;
}

